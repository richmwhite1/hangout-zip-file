"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, Clock } from "lucide-react"
import type { HangoutFormData } from "@/components/create-hangout-modal"

interface WhenStepProps {
  formData: HangoutFormData
  updateFormData: (updates: Partial<HangoutFormData>) => void
  onNext: () => void
}

const quickDates = [
  { label: "Today", value: new Date().toISOString().split("T")[0] },
  { label: "Tomorrow", value: new Date(Date.now() + 86400000).toISOString().split("T")[0] },
  { label: "This Weekend", value: getNextWeekend() },
  { label: "Next Week", value: getNextWeek() },
]

const quickTimes = [
  "9:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "1:00 PM",
  "2:00 PM",
  "3:00 PM",
  "4:00 PM",
  "5:00 PM",
  "6:00 PM",
  "7:00 PM",
  "8:00 PM",
]

function getNextWeekend() {
  const today = new Date()
  const saturday = new Date(today)
  saturday.setDate(today.getDate() + (6 - today.getDay()))
  return saturday.toISOString().split("T")[0]
}

function getNextWeek() {
  const today = new Date()
  const nextWeek = new Date(today)
  nextWeek.setDate(today.getDate() + 7)
  return nextWeek.toISOString().split("T")[0]
}

export function WhenStep({ formData, updateFormData, onNext }: WhenStepProps) {
  const canContinue = formData.date && formData.time

  return (
    <div className="space-y-6">
      <div className="text-center">
        <p className="text-muted-foreground">
          When should this hangout happen? Pick a date and time that works for everyone.
        </p>
      </div>

      {/* Quick Date Selection */}
      <div className="space-y-3">
        <label className="text-sm font-medium flex items-center space-x-2">
          <Calendar className="w-4 h-4" />
          <span>Quick Date Options</span>
        </label>
        <div className="grid grid-cols-2 gap-2">
          {quickDates.map((option) => (
            <Button
              key={option.label}
              variant={formData.date === option.value ? "default" : "outline"}
              onClick={() => updateFormData({ date: option.value })}
            >
              {option.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Custom Date */}
      <div className="space-y-2">
        <label className="text-sm font-medium">Or Pick a Specific Date</label>
        <Input
          type="date"
          value={formData.date}
          onChange={(e) => updateFormData({ date: e.target.value })}
          min={new Date().toISOString().split("T")[0]}
        />
      </div>

      {/* Time Selection */}
      <div className="space-y-3">
        <label className="text-sm font-medium flex items-center space-x-2">
          <Clock className="w-4 h-4" />
          <span>Time</span>
        </label>
        <div className="grid grid-cols-4 gap-2">
          {quickTimes.map((time) => (
            <Button
              key={time}
              variant={formData.time === time ? "default" : "outline"}
              size="sm"
              onClick={() => updateFormData({ time })}
            >
              {time}
            </Button>
          ))}
        </div>
      </div>

      {/* Custom Time */}
      <div className="space-y-2">
        <label className="text-sm font-medium">Or Enter Custom Time</label>
        <Input type="time" value={formData.time} onChange={(e) => updateFormData({ time: e.target.value })} />
      </div>

      {/* Selected Date & Time Preview */}
      {formData.date && formData.time && (
        <Card className="border-primary">
          <CardContent className="p-4">
            <div className="text-center">
              <h4 className="font-medium">Scheduled For</h4>
              <p className="text-lg font-bold text-primary">
                {new Date(formData.date).toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </p>
              <p className="text-muted-foreground">at {formData.time}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Continue Button */}
      <div className="flex justify-center pt-4">
        <Button onClick={onNext} disabled={!canContinue} size="lg">
          Review & Create
        </Button>
      </div>
    </div>
  )
}
