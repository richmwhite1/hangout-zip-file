"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Users, Calendar, MapPin, Tag, CheckCircle } from "lucide-react"
import type { HangoutFormData } from "@/components/create-hangout-modal"

interface ReviewStepProps {
  formData: HangoutFormData
  updateFormData: (updates: Partial<HangoutFormData>) => void
  onNext: () => void
}

const mockFriends = [
  { id: "1", name: "Sarah Chen", avatar: "/professional-woman-avatar.png" },
  { id: "2", name: "Mike Rodriguez", avatar: "/friendly-man-avatar.jpg" },
  { id: "3", name: "Alex Johnson", avatar: "/man-avatar.png" },
  { id: "4", name: "Maya Patel", avatar: "/diverse-woman-avatar.png" },
  { id: "5", name: "Jordan Kim", avatar: "/diverse-person-avatars.png" },
  { id: "6", name: "Sam Wilson", avatar: "/outdoorsy-man-avatar.jpg" },
  { id: "7", name: "Emma Davis", avatar: "/athletic-woman-avatar.jpg" },
  { id: "8", name: "Chris Lee", avatar: "/man-avatar.png" },
]

export function ReviewStep({ formData }: ReviewStepProps) {
  const selectedFriends = mockFriends.filter((friend) => formData.selectedFriends.includes(friend.id))

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
        <h3 className="text-xl font-bold">Almost Ready!</h3>
        <p className="text-muted-foreground">Review your hangout details before sending invitations.</p>
      </div>

      {/* Hangout Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Tag className="w-5 h-5" />
            <span>Hangout Details</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h4 className="font-bold text-lg">{formData.title}</h4>
            {formData.description && <p className="text-muted-foreground mt-1">{formData.description}</p>}
          </div>

          {formData.category && <Badge variant="secondary">{formData.category}</Badge>}
        </CardContent>
      </Card>

      {/* When & Where */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-base">
              <Calendar className="w-4 h-4" />
              <span>When</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-medium">{formatDate(formData.date)}</p>
            <p className="text-muted-foreground">at {formData.time}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-base">
              <MapPin className="w-4 h-4" />
              <span>Where</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {formData.venue && <p className="font-medium">{formData.venue}</p>}
            <p className="text-muted-foreground">{formData.location}</p>
          </CardContent>
        </Card>
      </div>

      {/* Invited Friends */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5" />
            <span>Invited Friends ({selectedFriends.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            {selectedFriends.map((friend) => (
              <div key={friend.id} className="flex items-center space-x-2">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={friend.avatar || "/placeholder.svg"} alt={friend.name} />
                  <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">{friend.name}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Create Button */}
      <div className="flex justify-center pt-4">
        <Button size="lg" className="px-8">
          <CheckCircle className="w-5 h-5 mr-2" />
          Create Hangout & Send Invites
        </Button>
      </div>
    </div>
  )
}
