"use client"

import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Coffee,
  Utensils,
  PaintRoller as GameController2,
  Mountain,
  Music,
  Camera,
  ShoppingBag,
  Dumbbell,
} from "lucide-react"
import type { HangoutFormData } from "@/components/create-hangout-modal"

interface WhatStepProps {
  formData: HangoutFormData
  updateFormData: (updates: Partial<HangoutFormData>) => void
  onNext: () => void
}

const categories = [
  { id: "coffee", label: "Coffee & Chat", icon: Coffee },
  { id: "food", label: "Food & Dining", icon: Utensils },
  { id: "games", label: "Games & Fun", icon: GameController2 },
  { id: "outdoor", label: "Outdoor Adventure", icon: Mountain },
  { id: "music", label: "Music & Arts", icon: Music },
  { id: "photography", label: "Photography", icon: Camera },
  { id: "shopping", label: "Shopping", icon: ShoppingBag },
  { id: "fitness", label: "Fitness & Sports", icon: Dumbbell },
]

export function WhatStep({ formData, updateFormData, onNext }: WhatStepProps) {
  const handleCategorySelect = (categoryId: string) => {
    const category = categories.find((c) => c.id === categoryId)
    updateFormData({ category: category?.label || "" })
  }

  const canContinue = formData.title.trim().length > 0

  return (
    <div className="space-y-6">
      <div className="text-center">
        <p className="text-muted-foreground">Give your hangout a catchy title and let people know what to expect!</p>
      </div>

      {/* Title Input */}
      <div className="space-y-2">
        <label className="text-sm font-medium">Hangout Title *</label>
        <Input
          placeholder="e.g., Weekend Coffee Meetup, Friday Game Night..."
          value={formData.title}
          onChange={(e) => updateFormData({ title: e.target.value })}
          className="text-lg"
        />
      </div>

      {/* Description */}
      <div className="space-y-2">
        <label className="text-sm font-medium">Description</label>
        <Textarea
          placeholder="Tell your friends what this hangout is all about. What should they expect? What should they bring?"
          value={formData.description}
          onChange={(e) => updateFormData({ description: e.target.value })}
          rows={3}
        />
      </div>

      {/* Category Selection */}
      <div className="space-y-3">
        <label className="text-sm font-medium">Category</label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {categories.map((category) => {
            const Icon = category.icon
            const isSelected = formData.category === category.label
            return (
              <Button
                key={category.id}
                variant={isSelected ? "default" : "outline"}
                className="flex flex-col items-center space-y-2 h-auto py-3"
                onClick={() => handleCategorySelect(category.id)}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs text-center">{category.label}</span>
              </Button>
            )
          })}
        </div>
        {formData.category && (
          <Badge variant="secondary" className="mt-2">
            Selected: {formData.category}
          </Badge>
        )}
      </div>

      {/* Quick Suggestions */}
      <div className="space-y-3">
        <label className="text-sm font-medium">Quick Suggestions</label>
        <div className="flex flex-wrap gap-2">
          {[
            "Casual Coffee Chat",
            "Board Game Night",
            "Hiking Adventure",
            "Movie Marathon",
            "Cooking Together",
            "Art Gallery Visit",
          ].map((suggestion) => (
            <Button
              key={suggestion}
              variant="ghost"
              size="sm"
              className="text-xs"
              onClick={() => updateFormData({ title: suggestion })}
            >
              {suggestion}
            </Button>
          ))}
        </div>
      </div>

      {/* Continue Button */}
      <div className="flex justify-center pt-4">
        <Button onClick={onNext} disabled={!canContinue} size="lg">
          Continue to Location
        </Button>
      </div>
    </div>
  )
}
