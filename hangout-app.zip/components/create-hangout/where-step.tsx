"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, Search, Star, Navigation } from "lucide-react"
import type { HangoutFormData } from "@/components/create-hangout-modal"

interface WhereStepProps {
  formData: HangoutFormData
  updateFormData: (updates: Partial<HangoutFormData>) => void
  onNext: () => void
}

const mockVenues = [
  {
    id: "1",
    name: "Blue Bottle Coffee",
    address: "123 Main St, Downtown",
    category: "Coffee Shop",
    rating: 4.5,
    distance: "0.3 miles",
    image: "/modern-coffee-shop.png",
  },
  {
    id: "2",
    name: "Central Park",
    address: "Central Park, New York",
    category: "Park",
    rating: 4.8,
    distance: "0.5 miles",
    image: "/mountain-hiking-trail-at-sunrise.jpg",
  },
  {
    id: "3",
    name: "The Game Lounge",
    address: "456 Oak Ave, Midtown",
    category: "Entertainment",
    rating: 4.3,
    distance: "0.8 miles",
    image: "/board-games-on-table-with-friends.jpg",
  },
]

export function WhereStep({ formData, updateFormData, onNext }: WhereStepProps) {
  const [searchQuery, setSearchQuery] = useState("")

  const handleVenueSelect = (venue: (typeof mockVenues)[0]) => {
    updateFormData({
      location: venue.address,
      venue: venue.name,
    })
  }

  const canContinue = formData.location.trim().length > 0

  return (
    <div className="space-y-6">
      <div className="text-center">
        <p className="text-muted-foreground">
          Where should everyone meet? Search for a specific place or enter a custom location.
        </p>
      </div>

      {/* Location Search */}
      <div className="space-y-2">
        <label className="text-sm font-medium">Search Location</label>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search for restaurants, cafes, parks..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Custom Location */}
      <div className="space-y-2">
        <label className="text-sm font-medium">Or Enter Custom Location</label>
        <div className="relative">
          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="e.g., My apartment, 123 Main St, Someone's house..."
            value={formData.location}
            onChange={(e) => updateFormData({ location: e.target.value })}
            className="pl-10"
          />
        </div>
      </div>

      {/* Selected Venue */}
      {formData.venue && (
        <Card className="border-primary">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium">{formData.venue}</h4>
                <p className="text-sm text-muted-foreground">{formData.location}</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => updateFormData({ venue: "", location: "" })}>
                Change
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Venue Suggestions */}
      <div className="space-y-3">
        <label className="text-sm font-medium">Popular Nearby Places</label>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {mockVenues.map((venue) => (
            <Card
              key={venue.id}
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => handleVenueSelect(venue)}
            >
              <CardContent className="p-4">
                <div className="flex items-start space-x-3">
                  <div className="w-16 h-16 bg-muted rounded-lg flex-shrink-0 overflow-hidden">
                    <img
                      src={venue.image || "/placeholder.svg"}
                      alt={venue.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium truncate">{venue.name}</h4>
                        <p className="text-sm text-muted-foreground truncate">{venue.address}</p>
                        <div className="flex items-center space-x-3 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {venue.category}
                          </Badge>
                          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span>{venue.rating}</span>
                          </div>
                          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                            <Navigation className="w-3 h-3" />
                            <span>{venue.distance}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Continue Button */}
      <div className="flex justify-center pt-4">
        <Button onClick={onNext} disabled={!canContinue} size="lg">
          Continue to Date & Time
        </Button>
      </div>
    </div>
  )
}
