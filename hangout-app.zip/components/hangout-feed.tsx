"use client"

import { useState, useMemo } from "react"
import { HangoutCard } from "@/components/hangout-card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

const mockHangouts = [
  {
    id: "1",
    title: "Weekend Coffee Meetup",
    description: "Casual coffee and catch up at the new downtown cafe",
    image: "/modern-coffee-shop.png",
    date: "2024-12-15",
    time: "10:00 AM",
    location: "Blue Bottle Coffee, Downtown",
    host: {
      name: "Sarah Chen",
      avatar: "/professional-woman-avatar.png",
    },
    participants: [
      { name: "Alex", avatar: "/man-avatar.png", status: "yes" },
      { name: "Maya", avatar: "/diverse-woman-avatar.png", status: "yes" },
      { name: "Jordan", avatar: "/diverse-person-avatars.png", status: "maybe" },
      { name: "Sam", avatar: "/diverse-person-avatars.png", status: "pending" },
    ],
    category: "Coffee & Chat",
    tags: ["coffee", "networking", "casual"],
    hasNewActivity: true,
    newCommentsCount: 2,
  },
  {
    id: "2",
    title: "Friday Night Gaming Session",
    description: "Board games and pizza at my place. Bring your competitive spirit!",
    image: "/board-games-on-table-with-friends.jpg",
    date: "2024-12-13",
    time: "7:00 PM",
    location: "Mike's Apartment",
    host: {
      name: "Mike Rodriguez",
      avatar: "/friendly-man-avatar.jpg",
    },
    participants: [
      { name: "Lisa", avatar: "/diverse-woman-avatar.png", status: "yes" },
      { name: "Tom", avatar: "/man-avatar.png", status: "yes" },
      { name: "Emma", avatar: "/diverse-woman-avatar.png", status: "yes" },
      { name: "Chris", avatar: "/man-avatar.png", status: "no" },
    ],
    category: "Games & Fun",
    tags: ["games", "pizza", "indoor"],
  },
  {
    id: "3",
    title: "Hiking Adventure at Sunset Peak",
    description: "Early morning hike to catch the sunrise. Moderate difficulty, amazing views!",
    image: "/mountain-hiking-trail-at-sunrise.jpg",
    date: "2024-12-16",
    time: "6:00 AM",
    location: "Sunset Peak Trailhead",
    host: {
      name: "David Kim",
      avatar: "/outdoorsy-man-avatar.jpg",
    },
    participants: [
      { name: "Anna", avatar: "/athletic-woman-avatar.jpg", status: "yes" },
      { name: "Ben", avatar: "/man-avatar.png", status: "maybe" },
      { name: "Zoe", avatar: "/diverse-woman-avatar.png", status: "pending" },
    ],
    category: "Outdoor Adventure",
    tags: ["hiking", "sunrise", "nature"],
  },
]

export function HangoutFeed() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeFilter, setActiveFilter] = useState("all")

  const filteredAndSortedHangouts = useMemo(() => {
    let filtered = mockHangouts

    // Filter by search query
    if (searchQuery.trim()) {
      filtered = filtered.filter(
        (hangout) =>
          hangout.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          hangout.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          hangout.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          hangout.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
      )
    }

    if (activeFilter === "all") {
      // Sort by recent activity (simulated - in real app this would be based on last comment/update time)
      return filtered.sort((a, b) => {
        // Simulate recent activity - events with comments show first
        const aHasActivity = a.hasNewActivity // Weekend Coffee has new comment
        const bHasActivity = b.hasNewActivity
        if (aHasActivity && !bHasActivity) return -1
        if (!aHasActivity && bHasActivity) return 1
        return new Date(a.date).getTime() - new Date(b.date).getTime()
      })
    }

    // Sort by date (upcoming first) for other filters
    return filtered.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  }, [searchQuery, activeFilter])

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <Button
          variant={activeFilter === "all" ? "secondary" : "ghost"}
          size="sm"
          className="text-xs px-3 py-1 h-7"
          onClick={() => setActiveFilter("all")}
        >
          All
        </Button>
        <Button
          variant={activeFilter === "upcoming" ? "secondary" : "ghost"}
          size="sm"
          className="text-xs px-3 py-1 h-7"
          onClick={() => setActiveFilter("upcoming")}
        >
          Upcoming
        </Button>
        <Button
          variant={activeFilter === "past" ? "secondary" : "ghost"}
          size="sm"
          className="text-xs px-3 py-1 h-7"
          onClick={() => setActiveFilter("past")}
        >
          Past Events
        </Button>
        <Button
          variant={activeFilter === "my" ? "secondary" : "ghost"}
          size="sm"
          className="text-xs px-3 py-1 h-7"
          onClick={() => setActiveFilter("my")}
        >
          My Events
        </Button>
        <Button
          variant={activeFilter === "invitations" ? "secondary" : "ghost"}
          size="sm"
          className="text-xs px-3 py-1 h-7"
          onClick={() => setActiveFilter("invitations")}
        >
          Invitations
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
        <Input
          placeholder="Search hangouts by title, description, or tags..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 bg-card border-border/50"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAndSortedHangouts.map((hangout) => (
          <HangoutCard key={hangout.id} hangout={hangout} />
        ))}
      </div>

      {filteredAndSortedHangouts.length === 0 && searchQuery && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No hangouts found matching "{searchQuery}"</p>
        </div>
      )}
    </div>
  )
}
