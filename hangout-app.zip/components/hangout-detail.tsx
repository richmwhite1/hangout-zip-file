"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Calendar,
  MapPin,
  Users,
  Share2,
  MessageSquare,
  Clock,
  Tag,
  ArrowLeft,
  Check,
  X,
  HelpCircle,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Crown,
  Star,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { ChatInterface } from "@/components/chat-interface"

interface Participant {
  id: string
  name: string
  avatar: string
  status: "yes" | "no" | "maybe" | "pending"
  role?: "host" | "co-host" | "mandatory" | "regular"
}

interface Hangout {
  id: string
  title: string
  description: string
  image: string
  photos?: string[] // Added photos array for carousel
  date: string
  time: string
  location: string
  address: string
  host: {
    id: string
    name: string
    avatar: string
    bio: string
  }
  participants: Participant[]
  category: string
  createdAt: string
  maxParticipants: number
  isPublic: boolean
  tags: string[]
}

interface HangoutDetailProps {
  hangout: Hangout
}

export function HangoutDetail({ hangout }: HangoutDetailProps) {
  const [userRsvp, setUserRsvp] = useState<"yes" | "no" | "maybe" | null>(null)
  const [activeTab, setActiveTab] = useState("details")
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0) // Added photo carousel state
  const [hoveredParticipants, setHoveredParticipants] = useState<{ show: boolean; x: number; y: number }>({
    show: false,
    x: 0,
    y: 0,
  })

  const allPhotos = [hangout.image, ...(hangout.photos || [])].filter(Boolean)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "yes":
        return "bg-green-500"
      case "no":
        return "bg-red-500"
      case "maybe":
        return "bg-yellow-500"
      default:
        return "bg-gray-400"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "yes":
        return <Check className="w-4 h-4" />
      case "no":
        return <X className="w-4 h-4" />
      case "maybe":
        return <HelpCircle className="w-4 h-4" />
      default:
        return <Clock className="w-4 h-4" />
    }
  }

  const getRoleBadge = (participant: Participant) => {
    if (participant.role === "host") {
      return <Crown className="w-3 h-3 text-yellow-500" />
    }
    if (participant.role === "co-host") {
      return <Star className="w-3 h-3 text-blue-500" />
    }
    if (participant.role === "mandatory") {
      return <div className="w-2 h-2 bg-red-500 rounded-full" />
    }
    return null
  }

  const yesCount = hangout.participants.filter((p) => p.status === "yes").length
  const maybeCount = hangout.participants.filter((p) => p.status === "maybe").length
  const noCount = hangout.participants.filter((p) => p.status === "no").length
  const goingParticipants = hangout.participants.filter((p) => p.status === "yes")
  const pendingParticipants = hangout.participants.filter((p) => p.status === "pending")

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const handleParticipantHover = (e: React.MouseEvent, show: boolean) => {
    if (show) {
      setHoveredParticipants({
        show: true,
        x: e.clientX,
        y: e.clientY,
      })
    } else {
      setHoveredParticipants({ show: false, x: 0, y: 0 })
    }
  }

  const nextPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev + 1) % allPhotos.length)
  }

  const prevPhoto = () => {
    setCurrentPhotoIndex((prev) => (prev - 1 + allPhotos.length) % allPhotos.length)
  }

  const hangoutConversation = {
    id: `conv-${hangout.id}`,
    type: "hangout" as const,
    title: hangout.title,
    participants: hangout.participants.map((p) => ({
      id: p.id,
      name: p.name,
      avatar: p.avatar,
    })),
    hangoutId: hangout.id,
  }

  return (
    <div className="space-y-6">
      <Link href="/">
        <Button variant="ghost" className="mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Feed
        </Button>
      </Link>

      <Card className="overflow-hidden border-border/50">
        <div className="relative">
          {allPhotos.length > 0 ? (
            <div className="relative">
              <Image
                src={allPhotos[currentPhotoIndex] || "/placeholder.svg"}
                alt={hangout.title}
                width={800}
                height={300}
                className="w-full h-64 object-cover"
              />
              {allPhotos.length > 1 && (
                <>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white"
                    onClick={prevPhoto}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white"
                    onClick={nextPhoto}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-1">
                    {allPhotos.map((_, index) => (
                      <button
                        key={index}
                        className={`w-2 h-2 rounded-full ${index === currentPhotoIndex ? "bg-white" : "bg-white/50"}`}
                        onClick={() => setCurrentPhotoIndex(index)}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="w-full h-64 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
              <div className="text-6xl">🎉</div>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-white font-semibold text-2xl text-balance mb-2">{hangout.title}</h1>
                <div className="flex items-center space-x-4 text-white/90">
                  <Badge variant="secondary" className="bg-black/50 text-white border-0 text-xs">
                    {hangout.category}
                  </Badge>
                  <div
                    className="flex items-center space-x-1 cursor-pointer"
                    onMouseEnter={(e) => handleParticipantHover(e, true)}
                    onMouseLeave={(e) => handleParticipantHover(e, false)}
                  >
                    <Users className="w-4 h-4" />
                    <span className="text-sm">{yesCount} going</span>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button variant="secondary" size="sm" className="bg-black/50 border-0 hover:bg-black/70">
                  <Share2 className="w-4 h-4" />
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setActiveTab("chat")}
                  className="bg-black/50 border-0 hover:bg-black/70"
                >
                  <MessageSquare className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 border-b border-border/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex -space-x-2">
                {goingParticipants.slice(0, 5).map((participant) => (
                  <div key={participant.id} className="relative">
                    <Avatar className="w-8 h-8 border-2 border-background">
                      <AvatarImage src={participant.avatar || "/placeholder.svg"} alt={participant.name} />
                      <AvatarFallback className="text-xs">{participant.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border border-background" />
                  </div>
                ))}
                {yesCount > 5 && (
                  <div className="w-8 h-8 bg-muted border-2 border-background rounded-full flex items-center justify-center">
                    <span className="text-xs font-medium">+{yesCount - 5}</span>
                  </div>
                )}
              </div>
              <div className="text-sm text-muted-foreground">
                {yesCount} going • {maybeCount} maybe • {pendingParticipants.length} pending
              </div>
            </div>
          </div>
        </div>
      </Card>

      {hoveredParticipants.show && goingParticipants.length > 0 && (
        <div
          className="fixed z-50 bg-popover border border-border/50 rounded-lg p-3 shadow-lg pointer-events-none"
          style={{
            left: hoveredParticipants.x + 10,
            top: hoveredParticipants.y - 10,
            transform: "translateY(-100%)",
          }}
        >
          <div className="space-y-2">
            <div className="text-xs font-medium text-muted-foreground">Going ({yesCount})</div>
            <div className="flex flex-col space-y-2 max-h-32 overflow-y-auto">
              {goingParticipants.slice(0, 5).map((participant) => (
                <div key={participant.id} className="flex items-center space-x-2">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src={participant.avatar || "/placeholder.svg"} alt={participant.name} />
                    <AvatarFallback className="text-xs">{participant.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs font-medium">{participant.name}</span>
                </div>
              ))}
              {goingParticipants.length > 5 && (
                <div className="text-xs text-muted-foreground">+{goingParticipants.length - 5} more</div>
              )}
            </div>
          </div>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-muted/50">
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="participants">People</TabsTrigger>
          <TabsTrigger value="chat">Chat</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Will you join?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-3">
                    <Button
                      variant={userRsvp === "yes" ? "default" : "outline"}
                      className="flex items-center space-x-2"
                      onClick={() => setUserRsvp("yes")}
                    >
                      <Check className="w-4 h-4" />
                      <span>Yes</span>
                    </Button>
                    <Button
                      variant={userRsvp === "maybe" ? "default" : "outline"}
                      className="flex items-center space-x-2"
                      onClick={() => setUserRsvp("maybe")}
                    >
                      <HelpCircle className="w-4 h-4" />
                      <span>Maybe</span>
                    </Button>
                    <Button
                      variant={userRsvp === "no" ? "default" : "outline"}
                      className="flex items-center space-x-2"
                      onClick={() => setUserRsvp("no")}
                    >
                      <X className="w-4 h-4" />
                      <span>No</span>
                    </Button>
                  </div>
                  {userRsvp && (
                    <div className="mt-4 p-3 bg-muted/50 rounded-lg">
                      <p className="text-sm text-muted-foreground">
                        {userRsvp === "yes" && "Great! We'll see you there."}
                        {userRsvp === "maybe" && "Thanks for letting us know."}
                        {userRsvp === "no" && "Maybe next time!"}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-lg">Details</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground leading-relaxed text-sm">{hangout.description}</p>

                  <Separator />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start space-x-3">
                      <Calendar className="w-4 h-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="font-medium text-sm">{formatDate(hangout.date)}</p>
                        <p className="text-xs text-muted-foreground">at {hangout.time}</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="font-medium text-sm">{hangout.location}</p>
                        <p className="text-xs text-muted-foreground">{hangout.address}</p>
                        <Button variant="link" className="p-0 h-auto text-xs">
                          <ExternalLink className="w-3 h-3 mr-1" />
                          Map
                        </Button>
                      </div>
                    </div>
                  </div>

                  {hangout.tags.length > 0 && (
                    <>
                      <Separator />
                      <div className="flex items-center space-x-2">
                        <Tag className="w-4 h-4 text-muted-foreground" />
                        <div className="flex flex-wrap gap-1">
                          {hangout.tags.map((tag) => (
                            <Badge key={tag} variant="outline" className="text-xs px-2 py-0.5">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-4">
              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-base">Host</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-start space-x-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={hangout.host.avatar || "/placeholder.svg"} alt={hangout.host.name} />
                      <AvatarFallback>{hangout.host.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h4 className="font-medium text-sm">{hangout.host.name}</h4>
                      <p className="text-xs text-muted-foreground">{hangout.host.bio}</p>
                      <Button variant="outline" size="sm" className="mt-2 bg-transparent text-xs h-7">
                        <MessageSquare className="w-3 h-3 mr-1" />
                        Message
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader>
                  <CardTitle className="text-base">Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <Button variant="outline" className="w-full justify-start bg-transparent text-xs h-8">
                    <Calendar className="w-3 h-3 mr-2" />
                    Add to Calendar
                  </Button>
                  <Button variant="outline" className="w-full justify-start bg-transparent text-xs h-8">
                    <Share2 className="w-3 h-3 mr-2" />
                    Share Event
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start bg-transparent text-xs h-8"
                    onClick={() => setActiveTab("chat")}
                  >
                    <MessageSquare className="w-3 h-3 mr-2" />
                    Group Chat
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="participants" className="mt-6">
          <Card className="border-border/50">
            <CardHeader>
              <CardTitle className="text-lg">Participants</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="all" className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-muted/50">
                  <TabsTrigger value="all" className="text-xs">
                    All ({hangout.participants.length})
                  </TabsTrigger>
                  <TabsTrigger value="yes" className="text-xs">
                    Going ({yesCount})
                  </TabsTrigger>
                  <TabsTrigger value="maybe" className="text-xs">
                    Maybe ({maybeCount})
                  </TabsTrigger>
                  <TabsTrigger value="no" className="text-xs">
                    No ({noCount})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="mt-4">
                  <div className="space-y-3">
                    {hangout.participants.map((participant) => (
                      <div key={participant.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="relative">
                            <Avatar className="w-8 h-8">
                              <AvatarImage src={participant.avatar || "/placeholder.svg"} alt={participant.name} />
                              <AvatarFallback className="text-xs">{participant.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div
                              className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border border-background flex items-center justify-center ${getStatusColor(participant.status)}`}
                            >
                              <div className="text-white text-xs scale-75">{getStatusIcon(participant.status)}</div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="font-medium text-sm">{participant.name}</span>
                            {getRoleBadge(participant)}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="capitalize text-xs">
                            {participant.status === "pending" ? "No Response" : participant.status}
                          </Badge>
                          {participant.status === "pending" && (
                            <Button variant="ghost" size="sm" className="text-xs h-6 px-2">
                              👋
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="yes" className="mt-4">
                  <div className="space-y-3">
                    {hangout.participants
                      .filter((p) => p.status === "yes")
                      .map((participant) => (
                        <div key={participant.id} className="flex items-center space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={participant.avatar || "/placeholder.svg"} alt={participant.name} />
                            <AvatarFallback className="text-xs">{participant.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-sm">{participant.name}</span>
                        </div>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="maybe" className="mt-4">
                  <div className="space-y-3">
                    {hangout.participants
                      .filter((p) => p.status === "maybe")
                      .map((participant) => (
                        <div key={participant.id} className="flex items-center space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={participant.avatar || "/placeholder.svg"} alt={participant.name} />
                            <AvatarFallback className="text-xs">{participant.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-sm">{participant.name}</span>
                        </div>
                      ))}
                  </div>
                </TabsContent>

                <TabsContent value="no" className="mt-4">
                  <div className="space-y-3">
                    {hangout.participants
                      .filter((p) => p.status === "no")
                      .map((participant) => (
                        <div key={participant.id} className="flex items-center space-x-3">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={participant.avatar || "/placeholder.svg"} alt={participant.name} />
                            <AvatarFallback className="text-xs">{participant.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-sm">{participant.name}</span>
                        </div>
                      ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chat" className="mt-6">
          <div className="h-[600px]">
            <ChatInterface conversation={hangoutConversation} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
