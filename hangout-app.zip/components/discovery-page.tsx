"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  MapPin,
  TrendingUp,
  Coffee,
  Utensils,
  Mountain,
  Music,
  Camera,
  Dumbbell,
  Users,
  Clock,
} from "lucide-react"
import { HangoutCard } from "@/components/hangout-card"

const categories = [
  { id: "all", label: "All", icon: Users, count: 24 },
  { id: "coffee", label: "Coffee", icon: Coffee, count: 8 },
  { id: "food", label: "Food", icon: Utensils, count: 6 },
  { id: "outdoor", label: "Outdoor", icon: Mountain, count: 4 },
  { id: "music", label: "Music", icon: Music, count: 3 },
  { id: "photo", label: "Photo", icon: Camera, count: 2 },
  { id: "fitness", label: "Fitness", icon: Dumbbell, count: 1 },
]

const mockPublicHangouts = [
  {
    id: "pub1",
    title: "Downtown Photography Walk",
    description: "Explore the city's architecture and street art with fellow photography enthusiasts.",
    image: "/modern-coffee-shop.png",
    date: "2024-12-22",
    time: "2:00 PM",
    location: "Downtown Arts District",
    host: {
      name: "Emma Davis",
      avatar: "/athletic-woman-avatar.jpg",
    },
    participants: [
      { name: "Alex", avatar: "/man-avatar.png", status: "yes" },
      { name: "Maya", avatar: "/diverse-woman-avatar.png", status: "yes" },
      { name: "Jordan", avatar: "/diverse-person-avatars.png", status: "maybe" },
    ],
    category: "Photography",
    isPublic: true,
    trending: true,
  },
  {
    id: "pub2",
    title: "Morning Yoga in the Park",
    description: "Start your day with peaceful yoga session surrounded by nature.",
    image: "/mountain-hiking-trail-at-sunrise.jpg",
    date: "2024-12-21",
    time: "7:00 AM",
    location: "Central Park",
    host: {
      name: "Sarah Chen",
      avatar: "/professional-woman-avatar.png",
    },
    participants: [
      { name: "Lisa", avatar: "/diverse-woman-avatar.png", status: "yes" },
      { name: "Tom", avatar: "/man-avatar.png", status: "yes" },
      { name: "Emma", avatar: "/athletic-woman-avatar.jpg", status: "yes" },
      { name: "Chris", avatar: "/man-avatar.png", status: "maybe" },
    ],
    category: "Fitness & Sports",
    isPublic: true,
    trending: false,
  },
  {
    id: "pub3",
    title: "Indie Music Night",
    description: "Discover new indie artists at this cozy venue. Great vibes and amazing music!",
    image: "/board-games-on-table-with-friends.jpg",
    date: "2024-12-23",
    time: "8:00 PM",
    location: "The Underground",
    host: {
      name: "Mike Rodriguez",
      avatar: "/friendly-man-avatar.jpg",
    },
    participants: [
      { name: "Anna", avatar: "/diverse-woman-avatar.png", status: "yes" },
      { name: "Ben", avatar: "/man-avatar.png", status: "yes" },
      { name: "Zoe", avatar: "/athletic-woman-avatar.jpg", status: "maybe" },
    ],
    category: "Music & Arts",
    isPublic: true,
    trending: true,
  },
  {
    id: "pub4",
    title: "Brunch & Book Club",
    description: "Discuss this month's book selection over delicious brunch and mimosas.",
    image: "/modern-coffee-shop.png",
    date: "2024-12-24",
    time: "11:00 AM",
    location: "Sunny Side Cafe",
    host: {
      name: "Jordan Kim",
      avatar: "/diverse-person-avatars.png",
    },
    participants: [
      { name: "Sarah", avatar: "/professional-woman-avatar.png", status: "yes" },
      { name: "Emma", avatar: "/athletic-woman-avatar.jpg", status: "yes" },
    ],
    category: "Coffee & Chat",
    isPublic: true,
    trending: false,
  },
]

export function DiscoveryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [locationFilter, setLocationFilter] = useState("")
  const [dateFilter, setDateFilter] = useState("")
  const [sortBy, setSortBy] = useState("trending")

  const filteredHangouts = mockPublicHangouts.filter((hangout) => {
    const matchesSearch =
      hangout.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      hangout.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || hangout.category.toLowerCase().includes(selectedCategory)
    const matchesLocation = !locationFilter || hangout.location.toLowerCase().includes(locationFilter.toLowerCase())

    return matchesSearch && matchesCategory && matchesLocation
  })

  const sortedHangouts = [...filteredHangouts].sort((a, b) => {
    if (sortBy === "trending") {
      return b.trending ? 1 : -1
    }
    if (sortBy === "date") {
      return new Date(a.date).getTime() - new Date(b.date).getTime()
    }
    if (sortBy === "participants") {
      return b.participants.length - a.participants.length
    }
    return 0
  })

  return (
    <div className="space-y-4">
      <div className="text-center space-y-1">
        <h1 className="text-2xl font-semibold tracking-tight">Discover</h1>
        <p className="text-muted-foreground text-sm">Find events near you</p>
      </div>

      <Card className="border-border/50">
        <CardContent className="p-4">
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search events..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-background border-border/50"
              />
            </div>

            <div className="flex gap-2 overflow-x-auto pb-2">
              <div className="relative min-w-0 flex-1">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Location"
                  value={locationFilter}
                  onChange={(e) => setLocationFilter(e.target.value)}
                  className="pl-10 bg-background border-border/50"
                />
              </div>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-32 bg-background border-border/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="trending">Trending</SelectItem>
                  <SelectItem value="date">Date</SelectItem>
                  <SelectItem value="participants">Popular</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardContent className="p-3">
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => {
              const Icon = category.icon
              return (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="flex items-center gap-1.5 whitespace-nowrap min-w-fit px-3"
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="text-xs">{category.label}</span>
                  <Badge variant="secondary" className="text-xs px-1.5 py-0">
                    {category.count}
                  </Badge>
                </Button>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-medium">
            {selectedCategory === "all" ? "All Events" : categories.find((c) => c.id === selectedCategory)?.label}
          </h2>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{sortedHangouts.length} found</span>
          </div>
        </div>

        {/* Trending Events */}
        {sortBy === "trending" && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              <h3 className="text-sm font-medium">Trending</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {sortedHangouts
                .filter((hangout) => hangout.trending)
                .map((hangout) => (
                  <div key={hangout.id} className="relative">
                    <Badge className="absolute top-2 left-2 z-10 bg-primary text-primary-foreground text-xs px-2 py-1">
                      <TrendingUp className="w-2.5 h-2.5 mr-1" />
                      Hot
                    </Badge>
                    <HangoutCard hangout={hangout} />
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* All Events */}
        <div className="space-y-3">
          {sortBy !== "trending" && <h3 className="text-sm font-medium">All Events</h3>}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(sortBy === "trending" ? sortedHangouts.filter((h) => !h.trending) : sortedHangouts).map((hangout) => (
              <HangoutCard key={hangout.id} hangout={hangout} />
            ))}
          </div>
        </div>

        {sortedHangouts.length === 0 && (
          <Card className="border-border/50">
            <CardContent className="p-8 text-center">
              <Search className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
              <h3 className="font-medium mb-1">No events found</h3>
              <p className="text-sm text-muted-foreground">Try different search terms or categories.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
