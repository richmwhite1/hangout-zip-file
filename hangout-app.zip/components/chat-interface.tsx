"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Send, Users, Phone, Video, MoreVertical, Smile, Camera } from "lucide-react"
import Image from "next/image"

interface Message {
  id: string
  senderId: string
  senderName: string
  senderAvatar: string
  content: string
  timestamp: string
  type: "text" | "system" | "image" // Added image message type
  imageUrl?: string // Added image URL for photo messages
}

interface Conversation {
  id: string
  type: "hangout" | "direct"
  title: string
  participants: Array<{
    id: string
    name: string
    avatar: string
  }>
  hangoutId?: string
}

interface ChatInterfaceProps {
  conversation: Conversation
}

const mockMessages: Record<string, Message[]> = {
  conv1: [
    {
      id: "msg1",
      senderId: "1",
      senderName: "Sarah Chen",
      senderAvatar: "/professional-woman-avatar.png",
      content: "Hey everyone! Really excited about our coffee meetup tomorrow. The weather looks perfect!",
      timestamp: "10:30 AM",
      type: "text",
    },
    {
      id: "msg2",
      senderId: "2",
      senderName: "Alex Johnson",
      senderAvatar: "/man-avatar.png",
      content: "Same here! I've been wanting to try that new cafe for weeks.",
      timestamp: "10:32 AM",
      type: "text",
    },
    {
      id: "msg3",
      senderId: "3",
      senderName: "Maya Patel",
      senderAvatar: "/diverse-woman-avatar.png",
      content: "Should we meet at 10 AM sharp or is 10:15 okay? I might be running a few minutes late.",
      timestamp: "10:35 AM",
      type: "text",
    },
    {
      id: "msg4",
      senderId: "1",
      senderName: "Sarah Chen",
      senderAvatar: "/professional-woman-avatar.png",
      content: "10:15 works perfectly! Looking forward to seeing everyone tomorrow!",
      timestamp: "2 min ago",
      type: "text",
    },
  ],
  conv2: [
    {
      id: "msg5",
      senderId: "4",
      senderName: "Mike Rodriguez",
      senderAvatar: "/friendly-man-avatar.jpg",
      content: "Game night is going to be epic! I've got Settlers of Catan and Ticket to Ride ready.",
      timestamp: "2:00 PM",
      type: "text",
    },
    {
      id: "msg6",
      senderId: "5",
      senderName: "Lisa Wang",
      senderAvatar: "/diverse-woman-avatar.png",
      content: "Perfect! Should I bring extra controllers for video games too?",
      timestamp: "15 min ago",
      type: "text",
    },
  ],
}

export function ChatInterface({ conversation }: ChatInterfaceProps) {
  const [newMessage, setNewMessage] = useState("")
  const [messages, setMessages] = useState<Message[]>(mockMessages[conversation.id] || [])
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null) // Added file input ref for photo uploads

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    setMessages(mockMessages[conversation.id] || [])
  }, [conversation.id])

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const message: Message = {
      id: `msg-${Date.now()}`,
      senderId: "current-user",
      senderName: "You",
      senderAvatar: "/placeholder.svg",
      content: newMessage,
      timestamp: "now",
      type: "text",
    }

    setMessages((prev) => [...prev, message])
    setNewMessage("")

    // Simulate a response after a short delay
    setTimeout(
      () => {
        const responses = ["Sounds great!", "I'm in!", "Looking forward to it!", "Perfect timing!", "Can't wait!"]
        const randomResponse = responses[Math.floor(Math.random() * responses.length)]
        const responseMessage: Message = {
          id: `msg-${Date.now()}-response`,
          senderId: conversation.participants[0]?.id || "1",
          senderName: conversation.participants[0]?.name || "Friend",
          senderAvatar: conversation.participants[0]?.avatar || "/placeholder.svg",
          content: randomResponse,
          timestamp: "now",
          type: "text",
        }
        setMessages((prev) => [...prev, responseMessage])
      },
      1000 + Math.random() * 2000,
    )
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const imageUrl = URL.createObjectURL(file)
      const message: Message = {
        id: `msg-${Date.now()}`,
        senderId: "current-user",
        senderName: "You",
        senderAvatar: "/placeholder.svg",
        content: "Shared a photo",
        timestamp: "now",
        type: "image",
        imageUrl,
      }
      setMessages((prev) => [...prev, message])
    }
  }

  return (
    <Card className="h-full flex flex-col">
      {/* Chat Header */}
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              {conversation.type === "hangout" ? (
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-primary-foreground" />
                </div>
              ) : (
                <Avatar className="w-10 h-10">
                  <AvatarImage
                    src={conversation.participants[0]?.avatar || "/placeholder.svg"}
                    alt={conversation.participants[0]?.name}
                  />
                  <AvatarFallback>{conversation.participants[0]?.name.charAt(0)}</AvatarFallback>
                </Avatar>
              )}
            </div>
            <div>
              <CardTitle className="text-lg">{conversation.title}</CardTitle>
              <div className="flex items-center space-x-2">
                {conversation.type === "hangout" ? (
                  <>
                    <Badge variant="secondary" className="text-xs">
                      Group Chat
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {conversation.participants.length} participants
                    </span>
                  </>
                ) : (
                  <span className="text-sm text-green-500">Online</span>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm">
              <Phone className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <Video className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      {/* Messages */}
      <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-start space-x-3 ${message.senderId === "current-user" ? "flex-row-reverse space-x-reverse" : ""}`}
          >
            <Avatar className="w-8 h-8">
              <AvatarImage src={message.senderAvatar || "/placeholder.svg"} alt={message.senderName} />
              <AvatarFallback className="text-xs">{message.senderName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className={`flex-1 ${message.senderId === "current-user" ? "text-right" : ""}`}>
              <div className="flex items-center space-x-2 mb-1">
                <span className="text-sm font-medium">{message.senderName}</span>
                <span className="text-xs text-muted-foreground">{message.timestamp}</span>
              </div>
              {message.type === "image" && message.imageUrl ? (
                <div className="inline-block">
                  <Image
                    src={message.imageUrl || "/placeholder.svg"}
                    alt="Shared photo"
                    width={200}
                    height={150}
                    className="rounded-lg object-cover max-w-xs"
                  />
                  <p className="text-xs text-muted-foreground mt-1">{message.content}</p>
                </div>
              ) : (
                <div
                  className={`inline-block p-3 rounded-lg max-w-xs lg:max-w-md ${
                    message.senderId === "current-user"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </CardContent>

      {/* Message Input */}
      <div className="border-t p-4">
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="sm">
            <Smile className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => fileInputRef.current?.click()}>
            <Camera className="w-4 h-4" />
          </Button>
          <input ref={fileInputRef} type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1"
          />
          <Button onClick={handleSendMessage} disabled={!newMessage.trim()}>
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  )
}
