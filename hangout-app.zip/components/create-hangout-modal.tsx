"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { WhoStep } from "@/components/create-hangout/who-step"
import { WhatStep } from "@/components/create-hangout/what-step"
import { WhereStep } from "@/components/create-hangout/where-step"
import { WhenStep } from "@/components/create-hangout/when-step"
import { ReviewStep } from "@/components/create-hangout/review-step"

interface CreateHangoutModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export interface HangoutFormData {
  selectedFriends: string[]
  title: string
  description: string
  category: string
  location: string
  venue: string
  date: string
  time: string
}

const steps = [
  { id: "who", title: "Who's Invited?", component: WhoStep },
  { id: "what", title: "What's the Plan?", component: WhatStep },
  { id: "where", title: "Where to Meet?", component: WhereStep },
  { id: "when", title: "When to Hangout?", component: WhenStep },
  { id: "review", title: "Review & Create", component: ReviewStep },
]

export function CreateHangoutModal({ open, onOpenChange }: CreateHangoutModalProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState<HangoutFormData>({
    selectedFriends: [],
    title: "",
    description: "",
    category: "",
    location: "",
    venue: "",
    date: "",
    time: "",
  })

  const updateFormData = (updates: Partial<HangoutFormData>) => {
    setFormData((prev) => ({ ...prev, ...updates }))
  }

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleClose = () => {
    setCurrentStep(0)
    setFormData({
      selectedFriends: [],
      title: "",
      description: "",
      category: "",
      location: "",
      venue: "",
      date: "",
      time: "",
    })
    onOpenChange(false)
  }

  const CurrentStepComponent = steps[currentStep].component
  const progress = ((currentStep + 1) / steps.length) * 100

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden bg-gray-900 border-gray-700 shadow-2xl backdrop-blur-sm text-white">
        <DialogHeader className="space-y-3 pb-2">
          <DialogTitle className="text-xl font-semibold text-white tracking-tight">
            {steps[currentStep].title}
          </DialogTitle>

          <div className="space-y-3">
            <Progress value={progress} className="h-1 bg-gray-800" />
            <div className="flex justify-between text-xs text-gray-400 font-medium">
              <span>
                {currentStep + 1}/{steps.length}
              </span>
              <span>{Math.round(progress)}%</span>
            </div>
          </div>

          <div className="flex justify-center space-x-1.5">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-all duration-200 ${
                  index <= currentStep ? "bg-primary shadow-sm" : "bg-gray-700"
                }`}
              />
            ))}
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto py-4">
          <CurrentStepComponent formData={formData} updateFormData={updateFormData} onNext={nextStep} />
        </div>

        <div className="flex justify-between pt-3 border-t border-gray-700">
          <Button
            variant="ghost"
            onClick={prevStep}
            disabled={currentStep === 0}
            className="text-gray-400 hover:text-white hover:bg-gray-800"
          >
            ← Back
          </Button>

          <div className="flex space-x-2">
            <Button variant="ghost" onClick={handleClose} className="text-gray-400 hover:text-white hover:bg-gray-800">
              Cancel
            </Button>
            {currentStep < steps.length - 1 ? (
              <Button onClick={nextStep} className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium">
                Next →
              </Button>
            ) : (
              <Button
                onClick={handleClose}
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
              >
                Create
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
