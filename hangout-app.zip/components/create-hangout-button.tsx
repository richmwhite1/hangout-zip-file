"use client"

import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export function CreateHangoutButton() {
  const router = useRouter()

  return (
    <Button size="lg" className="shadow-lg hover:shadow-xl transition-shadow" onClick={() => router.push("/create")}>
      <span className="mr-2 text-lg">+</span>
      Create Hangout
    </Button>
  )
}
