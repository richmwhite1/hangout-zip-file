"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"

const mockFriends = [
  { id: "1", name: "Sarah Chen", avatar: "/professional-woman-avatar.png", status: "online" },
  { id: "2", name: "Mike Rodriguez", avatar: "/friendly-man-avatar.jpg", status: "online" },
  { id: "3", name: "Alex Johnson", avatar: "/man-avatar.png", status: "away" },
  { id: "4", name: "Maya Patel", avatar: "/diverse-woman-avatar.png", status: "online" },
  { id: "5", name: "Jordan Kim", avatar: "/diverse-person-avatars.png", status: "offline" },
  { id: "6", name: "Sam Wilson", avatar: "/outdoorsy-man-avatar.jpg", status: "online" },
]

const mockGroups = [
  { id: "g1", name: "Coffee Crew", members: 4, avatar: "/coffee-group.jpg" },
  { id: "g2", name: "Hiking Squad", members: 6, avatar: "/diverse-hiking-group.png" },
  { id: "g3", name: "Game Night", members: 5, avatar: "/diverse-gaming-group.png" },
]

const activityPills = [
  { id: "coffee", label: "☕ Coffee", category: "food" },
  { id: "lunch", label: "🍽️ Lunch", category: "food" },
  { id: "dinner", label: "🍻 Dinner", category: "food" },
  { id: "movies", label: "🎬 Movies", category: "entertainment" },
  { id: "hiking", label: "🥾 Hiking", category: "outdoor" },
  { id: "drinks", label: "🍸 Drinks", category: "social" },
]

const quickDates = [
  { id: "today", label: "Today" },
  { id: "tomorrow", label: "Tomorrow" },
  { id: "weekend", label: "This Weekend" },
  { id: "next-week", label: "Next Week" },
]

const quickTimes = [
  { id: "morning", label: "Morning", time: "9:00 AM" },
  { id: "afternoon", label: "Afternoon", time: "2:00 PM" },
  { id: "evening", label: "Evening", time: "7:00 PM" },
]

export default function CreateHangoutPage() {
  const [selectedFriends, setSelectedFriends] = useState<string[]>([])
  const [selectedGroups, setSelectedGroups] = useState<string[]>([])
  const [participantRoles, setParticipantRoles] = useState<Record<string, { isMandatory: boolean; isCoHost: boolean }>>(
    {},
  )
  const [activity, setActivity] = useState("")
  const [location, setLocation] = useState("")
  const [selectedDate, setSelectedDate] = useState("")
  const [selectedTime, setSelectedTime] = useState("")
  const [customDateTime, setCustomDateTime] = useState("")
  const [showCalendar, setShowCalendar] = useState(false)
  const [isPoll, setIsPoll] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [showGroupCreation, setShowGroupCreation] = useState(false)
  const [newGroupName, setNewGroupName] = useState("")
  const [groupPhoto, setGroupPhoto] = useState<string | null>(null)
  const [showHangoutSettings, setShowHangoutSettings] = useState(false)
  const [hangoutPhoto, setHangoutPhoto] = useState<string | null>(null)
  const [privacy, setPrivacy] = useState<"public" | "friends">("friends")
  const [allowFriendsToInvite, setAllowFriendsToInvite] = useState(false)
  const [pollSettings, setPollSettings] = useState({
    allowMultipleVotes: false,
    allowSuggestions: false,
    consensusType: "percentage",
    consensusPercentage: 50,
    minimumParticipants: 2,
  })
  const [rsvpSettings, setRsvpSettings] = useState({ allowSuggestions: false, hostCanEdit: true, coHostCanEdit: false })

  const toggleFriend = (friendId: string) => {
    setSelectedFriends((prev) => (prev.includes(friendId) ? prev.filter((id) => id !== friendId) : [...prev, friendId]))
  }

  const toggleGroup = (groupId: string) => {
    setSelectedGroups((prev) => (prev.includes(groupId) ? prev.filter((id) => id !== groupId) : [...prev, groupId]))
  }

  const removeFriend = (friendId: string) => {
    setSelectedFriends((prev) => prev.filter((id) => id !== friendId))
    setParticipantRoles((prev) => {
      const updated = { ...prev }
      delete updated[friendId]
      return updated
    })
  }

  const removeGroup = (groupId: string) => {
    setSelectedGroups((prev) => prev.filter((id) => id !== groupId))
  }

  const toggleParticipantRole = (friendId: string, role: "mandatory" | "coHost") => {
    setParticipantRoles((prev) => ({
      ...prev,
      [friendId]: {
        isMandatory: role === "mandatory" ? !prev[friendId]?.isMandatory : prev[friendId]?.isMandatory || false,
        isCoHost: role === "coHost" ? !prev[friendId]?.isCoHost : prev[friendId]?.isCoHost || false,
      },
    }))
  }

  const selectedFriendObjects = mockFriends.filter((f) => selectedFriends.includes(f.id))
  const selectedGroupObjects = mockGroups.filter((g) => selectedGroups.includes(g.id))
  const canCreateGroup = selectedFriends.length >= 2

  const handlePhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setGroupPhoto(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removePhoto = () => {
    setGroupPhoto(null)
  }

  const handleHangoutPhotoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setHangoutPhoto(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeHangoutPhoto = () => {
    setHangoutPhoto(null)
  }

  const getFormattedDateTime = () => {
    if (customDateTime) {
      const date = new Date(customDateTime)
      return date.toLocaleDateString("en-US", {
        weekday: "long",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      })
    }

    if (selectedDate && selectedTime) {
      const dateLabel = quickDates.find((d) => d.id === selectedDate)?.label
      const timeLabel = quickTimes.find((t) => t.id === selectedTime)?.time
      return `${dateLabel} at ${timeLabel}`
    }

    return "Select date and time"
  }

  const getMandatoryParticipantsCount = () => {
    return Object.values(participantRoles).filter((role) => role.isMandatory).length
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-gradient-to-b from-gray-900 to-gray-950 border-b border-gray-800 px-4 py-4">
        <div className="flex items-center justify-between">
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            ✕
          </Button>
          <div className="text-center">
            <h1 className="text-lg font-bold text-white">{isPoll ? "Create Poll" : "Create Hangout"}</h1>
            <p className="text-xs text-gray-400">Draft saved</p>
          </div>
          <div className="relative">
            <input
              type="file"
              accept="image/*"
              onChange={handleHangoutPhotoUpload}
              className="hidden"
              id="hangout-photo-upload"
            />
            <label
              htmlFor="hangout-photo-upload"
              className="flex items-center justify-center w-8 h-8 bg-gray-800 hover:bg-gray-700 rounded-full cursor-pointer transition-colors"
              title="Upload hangout photo"
            >
              📷
            </label>
          </div>
        </div>

        {hangoutPhoto && (
          <div className="mt-4 relative">
            <div className="w-full h-32 bg-gray-800 rounded-lg overflow-hidden relative">
              <img src={hangoutPhoto || "/placeholder.svg"} alt="Hangout" className="w-full h-full object-cover" />
              <button
                onClick={removeHangoutPhoto}
                className="absolute top-2 right-2 w-6 h-6 bg-red-500 text-white rounded-full text-sm flex items-center justify-center hover:bg-red-600"
              >
                ×
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="px-4 pb-24 space-y-8">
        {/* WHO Section */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">👥 Who's invited?</h2>
            <div className="flex items-center gap-2">
              <Button
                variant={privacy === "friends" ? "default" : "outline"}
                size="sm"
                className={
                  privacy === "friends"
                    ? "bg-primary text-primary-foreground h-7 px-2 text-xs"
                    : "bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 h-7 px-2 text-xs"
                }
                onClick={() => setPrivacy("friends")}
              >
                Friends Only
              </Button>
              <Button
                variant={privacy === "public" ? "default" : "outline"}
                size="sm"
                className={
                  privacy === "public"
                    ? "bg-primary text-primary-foreground h-7 px-2 text-xs"
                    : "bg-gray-800 border-gray-700 text-gray-300 hover:bg-gray-700 h-7 px-2 text-xs"
                }
                onClick={() => setPrivacy("public")}
              >
                Public
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between bg-gray-800/50 rounded-lg p-3">
            <div>
              <div className="text-sm font-medium text-white">Allow friends to invite others</div>
              <div className="text-xs text-gray-400">Friends can add more people to this hangout</div>
            </div>
            <Switch checked={allowFriendsToInvite} onCheckedChange={setAllowFriendsToInvite} />
          </div>

          {/* Selected Friends/Groups */}
          {(selectedFriends.length > 0 || selectedGroups.length > 0) && (
            <div className="flex flex-wrap gap-2">
              {selectedFriendObjects.map((friend) => (
                <Badge
                  key={friend.id}
                  variant="secondary"
                  className="flex items-center gap-2 py-2 px-3 bg-gray-800 text-white relative"
                >
                  <Avatar className="w-4 h-4">
                    <AvatarImage src={friend.avatar || "/placeholder.svg"} alt={friend.name} />
                    <AvatarFallback className="text-xs">{friend.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm">{friend.name}</span>
                  <div className="flex gap-1">
                    {participantRoles[friend.id]?.isMandatory && (
                      <span className="text-xs bg-red-600 text-white px-1 rounded" title="Mandatory participant">
                        !
                      </span>
                    )}
                    {participantRoles[friend.id]?.isCoHost && (
                      <span className="text-xs bg-primary text-primary-foreground px-1 rounded" title="Co-host">
                        ★
                      </span>
                    )}
                  </div>
                  <button onClick={() => removeFriend(friend.id)} className="text-gray-400 hover:text-white">
                    ×
                  </button>
                </Badge>
              ))}
              {selectedGroupObjects.map((group) => (
                <Badge
                  key={group.id}
                  variant="secondary"
                  className="flex items-center gap-2 py-2 px-3 bg-primary/20 text-primary"
                >
                  <Avatar className="w-4 h-4">
                    <AvatarImage src={group.avatar || "/placeholder.svg"} alt={group.name} />
                    <AvatarFallback className="text-xs">{group.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm">{group.name}</span>
                  <button onClick={() => removeGroup(group.id)} className="text-primary/70 hover:text-primary">
                    ×
                  </button>
                </Badge>
              ))}
            </div>
          )}

          {selectedFriends.length > 0 && (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4 space-y-3">
                <h3 className="text-sm font-medium text-white">Participant Roles</h3>
                <div className="space-y-2">
                  {selectedFriendObjects.map((friend) => (
                    <div key={friend.id} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-6 h-6">
                          <AvatarImage src={friend.avatar || "/placeholder.svg"} alt={friend.name} />
                          <AvatarFallback className="text-xs">{friend.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm text-white">{friend.name}</span>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant={participantRoles[friend.id]?.isMandatory ? "default" : "outline"}
                          size="sm"
                          className={`h-7 px-2 text-xs ${
                            participantRoles[friend.id]?.isMandatory
                              ? "bg-red-600 hover:bg-red-700 text-white"
                              : "bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                          }`}
                          onClick={() => toggleParticipantRole(friend.id, "mandatory")}
                          title="Mandatory participant - must agree for poll to finalize"
                        >
                          ! Required
                        </Button>
                        <Button
                          variant={participantRoles[friend.id]?.isCoHost ? "default" : "outline"}
                          size="sm"
                          className={`h-7 px-2 text-xs ${
                            participantRoles[friend.id]?.isCoHost
                              ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                              : "bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
                          }`}
                          onClick={() => toggleParticipantRole(friend.id, "coHost")}
                          title="Co-host - can edit event details"
                        >
                          ★ Co-host
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-xs text-gray-400 space-y-1">
                  <div>
                    • <strong>Required (!)</strong>: Must agree before poll finalizes
                  </div>
                  <div>
                    • <strong>Co-host (★)</strong>: Can edit event details
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Quick Actions */}
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" size="sm" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
              Find Friends
            </Button>
            <Button variant="outline" size="sm" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
              Select Group
            </Button>
            {canCreateGroup && (
              <Button
                variant="outline"
                size="sm"
                className="bg-primary/10 border-primary/30 text-primary hover:bg-primary/20"
                onClick={() => setShowGroupCreation(!showGroupCreation)}
              >
                Create Group
              </Button>
            )}
          </div>

          {/* Group Creation */}
          {showGroupCreation && (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4 space-y-4">
                <div className="space-y-3">
                  <h3 className="text-sm font-medium text-white">Create New Group</h3>

                  {/* Photo Upload Section */}
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      {groupPhoto ? (
                        <div className="relative">
                          <Avatar className="w-16 h-16">
                            <AvatarImage src={groupPhoto || "/placeholder.svg"} alt="Group photo" />
                            <AvatarFallback className="bg-gray-700 text-white">
                              {newGroupName.charAt(0) || "G"}
                            </AvatarFallback>
                          </Avatar>
                          <button
                            onClick={removePhoto}
                            className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center hover:bg-red-600"
                          >
                            ×
                          </button>
                        </div>
                      ) : (
                        <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center border-2 border-dashed border-gray-600">
                          <span className="text-2xl">📷</span>
                        </div>
                      )}
                    </div>

                    <div className="flex-1">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                        id="group-photo-upload"
                      />
                      <label
                        htmlFor="group-photo-upload"
                        className="inline-flex items-center gap-2 px-3 py-2 text-sm bg-gray-700 hover:bg-gray-600 text-white rounded-md cursor-pointer transition-colors"
                      >
                        📷 {groupPhoto ? "Change Photo" : "Add Photo"}
                      </label>
                      <p className="text-xs text-gray-400 mt-1">Optional group photo</p>
                    </div>
                  </div>

                  {/* Group Name Input */}
                  <Input
                    placeholder="Enter group name..."
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    className="bg-gray-900 border-gray-600 text-white"
                  />

                  {/* Selected Friends Preview */}
                  <div className="space-y-2">
                    <p className="text-xs text-gray-400">Members ({selectedFriends.length})</p>
                    <div className="flex flex-wrap gap-1">
                      {selectedFriendObjects.slice(0, 4).map((friend) => (
                        <Avatar key={friend.id} className="w-6 h-6">
                          <AvatarImage src={friend.avatar || "/placeholder.svg"} alt={friend.name} />
                          <AvatarFallback className="text-xs">{friend.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                      ))}
                      {selectedFriends.length > 4 && (
                        <div className="w-6 h-6 bg-gray-600 rounded-full flex items-center justify-center text-xs text-white">
                          +{selectedFriends.length - 4}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                    disabled={!newGroupName.trim()}
                  >
                    Create Group
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setShowGroupCreation(false)
                      setNewGroupName("")
                      setGroupPhoto(null)
                    }}
                    className="text-gray-400 hover:text-white"
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Friend Grid */}
          <div className="grid grid-cols-2 gap-2">
            {mockFriends.map((friend) => (
              <Button
                key={friend.id}
                variant={selectedFriends.includes(friend.id) ? "default" : "outline"}
                className={`flex items-center gap-3 p-3 h-auto justify-start ${
                  selectedFriends.includes(friend.id)
                    ? "bg-primary text-primary-foreground"
                    : "bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
                }`}
                onClick={() => toggleFriend(friend.id)}
              >
                <div className="relative">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={friend.avatar || "/placeholder.svg"} alt={friend.name} />
                    <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div
                    className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-gray-800 ${
                      friend.status === "online"
                        ? "bg-green-500"
                        : friend.status === "away"
                          ? "bg-yellow-500"
                          : "bg-gray-400"
                    }`}
                  />
                </div>
                <div className="text-left">
                  <div className="font-medium text-sm">{friend.name}</div>
                  <div className="text-xs opacity-70 capitalize">{friend.status}</div>
                </div>
              </Button>
            ))}
          </div>
        </section>

        {/* WHAT Section */}
        <section className="space-y-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">📝 What are we doing?</h2>

          <Input
            placeholder="Coffee, lunch, movie night..."
            value={activity}
            onChange={(e) => setActivity(e.target.value)}
            className="bg-gray-800 border-gray-700 text-white text-lg py-3"
          />

          <div className="flex gap-2 flex-wrap">
            {activityPills.map((pill) => (
              <Button
                key={pill.id}
                variant={activity.toLowerCase().includes(pill.label.toLowerCase().slice(2)) ? "default" : "outline"}
                size="sm"
                className={
                  activity.toLowerCase().includes(pill.label.toLowerCase().slice(2))
                    ? "bg-primary text-primary-foreground"
                    : "bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
                }
                onClick={() => setActivity(pill.label.slice(2))}
              >
                {pill.label}
              </Button>
            ))}
          </div>
        </section>

        {/* WHERE Section */}
        <section className="space-y-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">📍 Where should we meet?</h2>

          <div className="flex gap-2">
            <Input
              placeholder="Location or venue..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="bg-gray-800 border-gray-700 text-white flex-1"
            />
            <Button
              variant="outline"
              size="sm"
              className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700 whitespace-nowrap"
            >
              📍 Central
            </Button>
          </div>

          {location && (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gray-700 rounded-lg flex items-center justify-center">📍</div>
                  <div>
                    <div className="font-medium text-white">{location}</div>
                    <div className="text-sm text-gray-400">0.5 miles away • Usually busy</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </section>

        {/* WHEN Section */}
        <section className="space-y-4">
          <h2 className="text-lg font-semibold text-white flex items-center gap-2">⏰ When should we hang out?</h2>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium text-white">{getFormattedDateTime()}</div>
                  <div className="text-sm text-gray-400">
                    {isPoll ? "Participants will vote on time options" : "Tap to change date and time"}
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-gray-700 border-gray-600 text-white hover:bg-gray-600"
                  onClick={() => setShowCalendar(!showCalendar)}
                >
                  📅
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="flex gap-2 flex-wrap">
            {quickDates.map((date) => (
              <Button
                key={date.id}
                variant={selectedDate === date.id ? "default" : "outline"}
                size="sm"
                className={
                  selectedDate === date.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
                }
                onClick={() => {
                  setSelectedDate(date.id)
                  setCustomDateTime("")
                }}
              >
                {date.label}
              </Button>
            ))}
          </div>

          {selectedDate && (
            <div className="flex gap-2 flex-wrap">
              {quickTimes.map((time) => (
                <Button
                  key={time.id}
                  variant={selectedTime === time.id ? "default" : "outline"}
                  size="sm"
                  className={
                    selectedTime === time.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
                  }
                  onClick={() => setSelectedTime(time.id)}
                >
                  {time.label}
                  <span className="text-xs opacity-70 ml-1">({time.time})</span>
                </Button>
              ))}
            </div>
          )}

          {showCalendar && (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-4 space-y-4">
                <h3 className="font-medium text-white">Custom Date & Time</h3>
                <Input
                  type="datetime-local"
                  value={customDateTime}
                  onChange={(e) => {
                    setCustomDateTime(e.target.value)
                    setSelectedDate("")
                    setSelectedTime("")
                  }}
                  className="bg-gray-900 border-gray-600 text-white"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowCalendar(false)}
                  className="text-gray-400 hover:text-white"
                >
                  Done
                </Button>
              </CardContent>
            </Card>
          )}
        </section>

        {/* Poll Toggle */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-white">Make this a poll instead</h3>
              <p className="text-sm text-gray-400">Let everyone vote on options</p>
            </div>
            <Switch checked={isPoll} onCheckedChange={setIsPoll} />
          </div>

          {/* Hangout Settings */}
          <div className="space-y-4">
            <Button
              variant="ghost"
              className="text-gray-400 hover:text-white p-0 h-auto text-sm"
              onClick={() => setShowHangoutSettings(!showHangoutSettings)}
            >
              ⚙️ Hangout Settings {showHangoutSettings ? "▼" : "▶"}
            </Button>

            {showHangoutSettings && (
              <div className="space-y-4 pl-4 border-l-2 border-gray-700">
                {isPoll ? (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-4 space-y-4">
                      <h3 className="font-medium text-white">Poll Settings</h3>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium text-white">Allow multiple votes</div>
                            <div className="text-xs text-gray-400">Participants can vote for multiple options</div>
                          </div>
                          <Switch
                            checked={pollSettings.allowMultipleVotes}
                            onCheckedChange={(checked) =>
                              setPollSettings((prev) => ({ ...prev, allowMultipleVotes: checked }))
                            }
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium text-white">Allow suggestions</div>
                            <div className="text-xs text-gray-400">Participants can suggest other options</div>
                          </div>
                          <Switch
                            checked={pollSettings.allowSuggestions}
                            onCheckedChange={(checked) =>
                              setPollSettings((prev) => ({ ...prev, allowSuggestions: checked }))
                            }
                          />
                        </div>

                        <div className="space-y-3">
                          <div className="text-sm font-medium text-white">Auto-finalize when:</div>

                          {getMandatoryParticipantsCount() > 0 && (
                            <div className="bg-red-900/20 border border-red-800 rounded-lg p-3">
                              <div className="text-sm text-red-300 font-medium">Mandatory Participants</div>
                              <div className="text-xs text-red-400">
                                {getMandatoryParticipantsCount()} required participant(s) must agree before
                                auto-finalizing
                              </div>
                            </div>
                          )}

                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="percentage"
                                name="consensus"
                                checked={pollSettings.consensusType === "percentage"}
                                onChange={() => setPollSettings((prev) => ({ ...prev, consensusType: "percentage" }))}
                                className="text-primary"
                              />
                              <label htmlFor="percentage" className="text-sm text-white flex-1">
                                {pollSettings.consensusPercentage}% of participants agree
                              </label>
                            </div>

                            {pollSettings.consensusType === "percentage" && (
                              <div className="ml-6 space-y-2">
                                <Slider
                                  value={[pollSettings.consensusPercentage]}
                                  onValueChange={([value]) =>
                                    setPollSettings((prev) => ({ ...prev, consensusPercentage: value }))
                                  }
                                  max={100}
                                  min={50}
                                  step={5}
                                  className="w-full"
                                />
                                <div className="text-xs text-gray-400">
                                  Auto-finalize when {pollSettings.consensusPercentage}% vote for the same option
                                  {getMandatoryParticipantsCount() > 0 && " (including all required participants)"}
                                </div>
                              </div>
                            )}
                          </div>

                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <input
                                type="radio"
                                id="minimum"
                                name="consensus"
                                checked={pollSettings.consensusType === "minimum"}
                                onChange={() => setPollSettings((prev) => ({ ...prev, consensusType: "minimum" }))}
                                className="text-primary"
                              />
                              <label htmlFor="minimum" className="text-sm text-white flex-1">
                                Minimum {pollSettings.minimumParticipants} participants agree
                              </label>
                            </div>

                            {pollSettings.consensusType === "minimum" && (
                              <div className="ml-6 space-y-2">
                                <Input
                                  type="number"
                                  min="2"
                                  max="20"
                                  value={pollSettings.minimumParticipants}
                                  onChange={(e) =>
                                    setPollSettings((prev) => ({
                                      ...prev,
                                      minimumParticipants: Number.parseInt(e.target.value) || 2,
                                    }))
                                  }
                                  className="bg-gray-900 border-gray-600 text-white w-20"
                                />
                                <div className="text-xs text-gray-400">
                                  Auto-finalize when {pollSettings.minimumParticipants} people vote for the same option
                                  {getMandatoryParticipantsCount() > 0 && " (including all required participants)"}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="bg-gray-800 border-gray-700">
                    <CardContent className="p-4 space-y-4">
                      <h3 className="font-medium text-white">Event Settings</h3>

                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium text-white">Allow suggestions</div>
                            <div className="text-xs text-gray-400">Participants can suggest changes to the plan</div>
                          </div>
                          <Switch
                            checked={rsvpSettings.allowSuggestions}
                            onCheckedChange={(checked) =>
                              setRsvpSettings((prev) => ({ ...prev, allowSuggestions: checked }))
                            }
                          />
                        </div>

                        <div className="space-y-2">
                          <div className="text-sm font-medium text-white">Who can edit this event:</div>
                          <div className="space-y-2 ml-2">
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                id="host-edit"
                                checked={rsvpSettings.hostCanEdit}
                                onChange={(e) =>
                                  setRsvpSettings((prev) => ({ ...prev, hostCanEdit: e.target.checked }))
                                }
                                className="text-primary"
                              />
                              <label htmlFor="host-edit" className="text-sm text-white">
                                Host (you)
                              </label>
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="checkbox"
                                id="cohost-edit"
                                checked={rsvpSettings.coHostCanEdit}
                                onChange={(e) =>
                                  setRsvpSettings((prev) => ({ ...prev, coHostCanEdit: e.target.checked }))
                                }
                                className="text-primary"
                              />
                              <label htmlFor="cohost-edit" className="text-sm text-white">
                                Co-hosts
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </div>
        </section>

        {/* Advanced Features */}
        <section className="space-y-4">
          <Button
            variant="ghost"
            className="text-gray-400 hover:text-white p-0 h-auto"
            onClick={() => setShowAdvanced(!showAdvanced)}
          >
            + Advanced Options
          </Button>

          {showAdvanced && (
            <div className="space-y-4 pl-4 border-l-2 border-gray-800">
              <Button variant="outline" size="sm" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                + Add Tasks
              </Button>
              <Button variant="outline" size="sm" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                + Add Agenda
              </Button>
              <Button variant="outline" size="sm" className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
                + Event Settings
              </Button>
            </div>
          )}
        </section>

        {/* Live Preview */}
        <section className="space-y-4">
          <h3 className="font-medium text-white">Preview</h3>
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              {hangoutPhoto ? (
                <div className="w-full h-32 bg-gray-700 rounded-lg overflow-hidden mb-4">
                  <img src={hangoutPhoto || "/placeholder.svg"} alt="Hangout" className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-full h-32 bg-gray-700 rounded-lg flex items-center justify-center mb-4">
                  <div className="text-4xl">🎉</div>
                </div>
              )}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Avatar className="w-10 h-10">
                    <AvatarFallback>You</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium text-white">
                      {activity || (isPoll ? "New Poll" : "New Hangout")}
                      {isPoll && (
                        <Badge variant="secondary" className="ml-2 text-xs">
                          POLL
                        </Badge>
                      )}
                      <Badge variant="outline" className="ml-2 text-xs border-gray-600 text-gray-400">
                        {privacy === "public" ? "🌍 Public" : "👥 Friends"}
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-400">{getFormattedDateTime()}</div>
                  </div>
                </div>
                {location && <div className="text-sm text-gray-400">📍 {location}</div>}
                <div className="flex gap-2">
                  {isPoll ? (
                    <>
                      <Button size="sm" className="bg-primary text-primary-foreground">
                        Vote
                      </Button>
                      {pollSettings.allowSuggestions && (
                        <Button size="sm" variant="outline" className="border-gray-600 text-gray-300 bg-transparent">
                          + Suggest
                        </Button>
                      )}
                    </>
                  ) : (
                    <>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white">
                        ✓ Going
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-yellow-600 text-yellow-600 hover:bg-yellow-600 hover:text-white bg-transparent"
                      >
                        ? Maybe
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-600 text-red-600 hover:bg-red-600 hover:text-white bg-transparent"
                      >
                        ✗ Can't
                      </Button>
                      {rsvpSettings.allowSuggestions && (
                        <Button size="sm" variant="outline" className="border-gray-600 text-gray-300 bg-transparent">
                          💡 Suggest
                        </Button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>

      {/* Sticky Footer */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-gray-800 p-4">
        <div className="flex gap-2">
          <Button variant="outline" className="flex-1 bg-gray-800 border-gray-700 text-white hover:bg-gray-700">
            Save Draft
          </Button>
          <Button className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
            {isPoll ? "Create Poll" : "Send Hangout"}
          </Button>
        </div>
      </div>
    </div>
  )
}
