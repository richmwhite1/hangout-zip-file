import { HangoutFeed } from "@/components/hangout-feed"
import { Navigation } from "@/components/navigation"
import { HangoutCalendar } from "@/components/hangout-calendar"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background text-foreground dark">
      <Navigation />
      <main className="container mx-auto px-4 py-6 max-w-4xl">
        <div className="mb-8">
          <HangoutCalendar />
        </div>

        <HangoutFeed />
      </main>
    </div>
  )
}
