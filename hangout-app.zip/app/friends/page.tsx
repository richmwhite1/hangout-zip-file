import { FriendsPage } from "@/components/friends-page"

export default function Friends() {
  return <FriendsPage />
}
