import { HangoutDetail } from "@/components/hangout-detail"
import { Navigation } from "@/components/navigation"

// Mock data - in a real app this would come from a database
const mockHangout = {
  id: "1",
  title: "Weekend Coffee Meetup",
  description:
    "Casual coffee and catch up at the new downtown cafe. We'll be discussing our upcoming projects and just enjoying each other's company. Feel free to bring your laptop if you want to work on something together!",
  image: "/modern-coffee-shop.png",
  date: "2024-01-20",
  time: "10:00 AM",
  location: "Blue Bottle Coffee, Downtown",
  address: "123 Main St, Downtown District",
  host: {
    id: "host1",
    name: "Sarah Chen",
    avatar: "/professional-woman-avatar.png",
    bio: "Product Manager at TechCorp, coffee enthusiast",
  },
  participants: [
    { id: "1", name: "Alex", avatar: "/man-avatar.png", status: "yes" },
    { id: "2", name: "Maya", avatar: "/diverse-woman-avatar.png", status: "yes" },
    { id: "3", name: "Jordan", avatar: "/diverse-person-avatars.png", status: "maybe" },
    { id: "4", name: "Sam", avatar: "/diverse-person-avatars.png", status: "pending" },
    { id: "5", name: "Emma", avatar: "/athletic-woman-avatar.jpg", status: "no" },
  ],
  category: "Coffee & Chat",
  createdAt: "2024-01-15",
  maxParticipants: 8,
  isPublic: false,
  tags: ["coffee", "networking", "casual"],
}

interface HangoutPageProps {
  params: {
    id: string
  }
}

export default function HangoutPage({ params }: HangoutPageProps) {
  return (
    <div className="min-h-screen bg-background text-foreground dark">
      <Navigation />
      <main className="container mx-auto px-4 py-6 max-w-4xl">
        <HangoutDetail hangout={mockHangout} />
      </main>
    </div>
  )
}
